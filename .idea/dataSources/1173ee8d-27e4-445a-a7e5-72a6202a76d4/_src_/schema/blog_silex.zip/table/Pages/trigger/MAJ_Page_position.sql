CREATE TRIGGER `MAJ_Page_position`
BEFORE INSERT ON `Pages`
FOR EACH ROW
  BEGIN
    DECLARE maxPos int default 0;

    IF ISNULL(NEW.position) THEN
      SELECT MAX(position) FROM pages
      INTO maxPos;

      SET NEW.position = (maxPos + 1);
    END IF;

  END